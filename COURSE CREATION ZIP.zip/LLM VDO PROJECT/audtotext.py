# Import necessary libraries
import streamlit as st
import yt_dlp
from moviepy.editor import VideoFileClip
import os
import time
import speech_recognition as sr
from pydub import AudioSegment
from pydub.silence import split_on_silence

# Initialize recognizer class (for recognizing the speech)
r = sr.Recognizer()
# Streamlit UI
st.title("YouTube Video to Audio Converter and Transcriber")

# Input field for video URL
video_url = st.text_input("Enter the YouTube video URL")

# Folder to store downloaded files
download_folder = "downloads"
os.makedirs(download_folder, exist_ok=True)

# Function to download video using yt-dlp
def download_video_yt_dlp(video_url, output_path):
    try:
        ydl_opts = {
            'format': 'best[ext=mp4]',  # Get the best format that is a single mp4 file (no merging needed)
            'outtmpl': os.path.join(output_path, '%(id)s_downloaded_video.%(ext)s'),  # Unique name using video ID
            'noplaylist': True  # Ensures only one video is downloaded, not a playlist
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(video_url, download=True)
            video_file_path = ydl.prepare_filename(info_dict)
            return True, video_file_path
    except Exception as e:
        return False, f"Error downloading video: {e}"

# Function to convert video to audio
def video_to_audio(video_path, output_audio_path):
    try:
        video = VideoFileClip(video_path)
        audio = video.audio
        audio.write_audiofile(output_audio_path, codec='pcm_s16le')  # Specify WAV codec
        return True, output_audio_path
    except Exception as e:
        return False, f"Error converting video to audio: {e}"

# Function to transcribe audio using Google Speech Recognition
def transcribe_audio(path):
    """This function takes the path of an audio file as input and returns the transcribed text."""
    with sr.AudioFile(path) as source:
        audio_listened = r.record(source)
        try:
            text = r.recognize_google(audio_listened)
        except sr.UnknownValueError:
            text = ""  # If Google API couldn't understand the audio
        except sr.RequestError as e:
            text = f"API request error: {e}"
    return text

# Function to split the audio into chunks based on silence and transcribe each chunk
def get_large_audio_transcription_on_silence(path):
    """Splits a large audio file into chunks based on silence,
    and transcribes each chunk individually using speech recognition."""
    # Load the audio file using pydub
    sound = AudioSegment.from_file(path)
    
    # Split the audio where silence is at least 500 milliseconds and low enough in volume
    chunks = split_on_silence(sound,
                              min_silence_len=500,  # Minimum length of silence in milliseconds
                              silence_thresh=sound.dBFS-14,  # Silence threshold in decibels
                              keep_silence=500)  # Include silence at the beginning and end of each chunk
    
    folder_name = "audio-chunks"
    if not os.path.isdir(folder_name):
        os.mkdir(folder_name)
    
    whole_text = ""
    
    # Process each chunk for transcription
    for i, audio_chunk in enumerate(chunks, start=1):
        chunk_filename = os.path.join(folder_name, f"chunk{i}.wav")
        audio_chunk.export(chunk_filename, format="wav")
        
        # Transcribe the chunk using the transcribe_audio function
        chunk_text = transcribe_audio(chunk_filename)
        
        if chunk_text:
            chunk_text = f"{chunk_text.capitalize()}. "
            whole_text += chunk_text
            print(f"Chunk {i}: {chunk_text}")
        else:
            print(f"Chunk {i}: Could not understand the audio.")
    
    # Return the transcribed text for the entire audio file
    return whole_text

# Handle video download, conversion, and transcription when button is clicked
if st.button("Download, Convert, and Transcribe"):
    if video_url:
        # Create a unique filename based on the current time
        timestamp = int(time.time())
        video_file = os.path.join(download_folder, f"downloaded_video_{timestamp}.mp4")
        audio_file = os.path.join(download_folder, f"extracted_audio_{timestamp}.wav")
        
        # Step 1: Download the video using yt-dlp
        st.write("Downloading video, please wait...")
        success, message_or_video_file = download_video_yt_dlp(video_url, download_folder)
        
        if success:
            st.success(f"Video downloaded successfully: {message_or_video_file}")
            
            # Step 2: Convert the video to audio
            st.write("Converting video to audio, please wait...")
            success, message_or_audio_file = video_to_audio(message_or_video_file, audio_file)
            
            if success:
                st.success(f"Audio extracted successfully: {message_or_audio_file}")
                
                # Step 3: Transcribe the audio to text
                st.write("Transcribing audio to text, please wait...")
                transcription = get_large_audio_transcription_on_silence(message_or_audio_file)
                
                if transcription:
                    st.success("Transcription completed successfully!")
                    st.text_area("Transcription", transcription, height=300)
                    
                    # Provide a download link for the transcription as a text file
                    transcription_file = os.path.join(download_folder, f"transcription_{timestamp}.txt")
                    with open(transcription_file, "w") as f:
                        f.write(transcription)
                    
                    with open(transcription_file, "rb") as f:
                        st.download_button(
                            label="Download Transcription",
                            data=f,
                            file_name=f"transcription_{timestamp}.txt",
                            mime="text/plain"
                        )
                else:
                    st.error("Failed to transcribe the audio.")
            else:
                st.error(message_or_audio_file)
        else:
            st.error(message_or_video_file)
    else:
        st.write("Please enter a valid video URL.")