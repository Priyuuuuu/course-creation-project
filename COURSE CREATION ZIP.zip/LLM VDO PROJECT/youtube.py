##new

# Required packages
# pip install streamlit gtts python-pptx moviepy Pillow langchain_google_genai comtypes
from googleapiclient.discovery import build
from youtube_transcript_api import YouTubeTranscriptApi
from google.api_core.exceptions import ResourceExhausted
import streamlit as st
from moviepy.editor import ImageClip, concatenate_videoclips, AudioFileClip
from pptx import Presentation
from gtts import gTTS
import tempfile
import time
import random
import os
import json
import pythoncom
import comtypes.client
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate

API_KEY = "AIzaSyCCxyOW4hHwVZVJ85g3LcJfVEPGYu_sRn0"
youtube = build("youtube", "v3", developerKey=API_KEY)


# Google API Key setup (for Langchain with Google Gemini)
os.environ["GOOGLE_API_KEY"] = "AIzaSyCuH25rpiDYyVYxEq7M59toDEC8ZhnN1F8"

import streamlit as st
from googleapiclient.discovery import build
from youtube_transcript_api import YouTubeTranscriptApi
import google.generativeai as genai

# Set up YouTube Data API
API_KEY = "AIzaSyAe9nQVoc9KuZbljckF-n-tpNjQ2CvqTn0"  # Replace with your actual API key
youtube = build("youtube", "v3", developerKey=API_KEY)

# # Configure the Gemini API
gemini_key = "AIzaSyCuH25rpiDYyVYxEq7M59toDEC8ZhnN1F8"  # Replace with your actual Gemini API key
genai.configure(api_key=gemini_key)
model = genai.GenerativeModel('models/gemini-1.0-pro')

def youtube_search(query, max_results=5):
    """Searches YouTube for videos based on the query and returns only videos with transcripts."""
    results = []
    next_page_token = None


    while len(results) < max_results:
        search_results = youtube.search().list(
            q=query,
            part="snippet",
            maxResults=10,
            pageToken=next_page_token,
            type="video",
            order="relevance"
        ).execute()

        for item in search_results['items']:
            video_id = item['id']['videoId']
            if has_transcript(video_id):
                results.append({
                    "title": item['snippet']['title'],
                    "url": f"https://www.youtube.com/watch?v={video_id}",
                    "video_id": video_id
                })
            if len(results) >= max_results:
                break

        next_page_token = search_results.get('nextPageToken')
        if not next_page_token:
            break

    return results

def has_transcript(video_id):
    """Returns True if a transcript is available for the given YouTube video ID."""
    try:
        YouTubeTranscriptApi.get_transcript(video_id)
        return True
    except Exception:
        return False

def get_transcript(video_id):
    """Fetches the transcript from a YouTube video ID."""
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        return " ".join([t['text'] for t in transcript])
    except Exception as e:
        st.error(f"Error getting transcript: {e}")
        return None

def summarize_transcripts(combined_transcript):
    """Summarizes the combined transcript using the Gemini API."""
    prompt = f"Summarize the following content into a concise transcript: {combined_transcript}"
    response = model.generate_content(prompt)
    return response.text


# Define a prompt to convert text to a structured JSON object
PROMPT = """
Summarize the input text and arrange it in an array of JSON objects to be suitable for a PowerPoint presentation.
Determine the needed number of JSON objects (slides) based on the length of the text.
Each key point in a slide should be limited to up to 10 words.
Consider a maximum of 5 bullet points per slide.
Return the response as an array of JSON objects.
The first item in the list must be a JSON object for the title slide.
This is a sample of such a JSON object:
{{
    "id": 1,
    "title_text": "My Presentation Title",
    "subtitle_text": "My presentation subtitle",
    "is_title_slide": "yes"
}}
And here is a sample of JSON data for slides:
{{
    "id": 2,
    "title_text": "Slide 1 Title",
    "text": ["Bullet 1", "Bullet 2"]
}}
Make sure the JSON object is correct and valid. Don't output explanations. I just need the JSON array as output.
"""

# Step 2: Function to generate JSON response using Gemini (Google Generative AI)
def generate_ppt_json(input_text: str) -> list:
    # Initialize Gemini model from Google
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-pro",
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=10,
        backoff_factor=3,
        verbose=True,
        streaming=True,
    )

    # Create the prompt template
    prompt = ChatPromptTemplate(
        [
            ("system", PROMPT),
            ("human", "{input_text}")
        ]
    )

    # Run the prompt through the model
    chain = prompt | llm

    # Implementing the exponential backoff logic
    max_retries = 5  # Maximum number of retries
    retries = 0

    while retries < max_retries:
        try:
            # Run the prompt through the model
            ai_response = chain.invoke({"input_text": input_text})
            print(f"AI Response: {ai_response.content}")
            slides_json = json.loads(ai_response.content)
            return slides_json
        except ResourceExhausted:
            wait_time = 2 ** retries + random.uniform(0, 1)  # Exponential backoff
            print(f"Resource exhausted. Retrying in {wait_time:.2f} seconds...")
            time.sleep(wait_time)  # Wait before retrying
            retries += 1  # Increment retry count

        # Parse the response as JSON


    raise Exception("Max retries exceeded while calling the API.")  # Raise an exception after max retries

# Function to create PowerPoint slides using python-pptx
def create_ppt_from_json(slides_json: list, output_file: str):
    # Initialize PowerPoint presentation
    prs = Presentation()

    for slide_data in slides_json:
        if slide_data.get("is_title_slide", "no") == "yes":
            # Create the title slide
            slide_layout = prs.slide_layouts[0]  # Title slide layout
            slide = prs.slides.add_slide(slide_layout)
            title = slide.shapes.title
            subtitle = slide.placeholders[1]

            title.text = slide_data.get("title_text", "")
            subtitle.text = slide_data.get("subtitle_text", "")
        else:
            # Create a slide with bullet points
            slide_layout = prs.slide_layouts[1]  # Title and content layout
            slide = prs.slides.add_slide(slide_layout)
            title = slide.shapes.title
            body = slide.shapes.placeholders[1].text_frame

            title.text = slide_data.get("title_text", "")
            for bullet in slide_data.get("text", []):
                p = body.add_paragraph()
                p.text = bullet

    # Save the PowerPoint presentation
    prs.save(output_file)
    
# Function to generate context-aware slide narration using Langchain
def generate_slide_audio(slides_json, audio_folder):
    audio_files = []
    audio_durations = []  # List to keep track of audio durations

    os.environ["GOOGLE_API_KEY"] = "AIzaSyDWZeuJjo2RemQUoGbbOcvE5hpXMo92Fv8"

    # Initialize the LLM from Langchain
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-pro",
        temperature=0.5,  # Adjust for more creative responses
        max_tokens=150,  # Set a reasonable token limit for the output
    )

    for slide in slides_json:
        title_text = slide.get('title_text', '')
        subtitle_text = slide.get('subtitle_text', '')

        if slide.get("is_title_slide", "no") == "yes":
            text_to_speak = f"{title_text}. {subtitle_text}."
            content_list = []  # No bullet points for title slide
        else:
            content_list = slide.get('text', [])
            text_to_speak = f"{title_text}. " + ". ".join(content_list) + "."

        # Prepare the prompt for voice-over generation
        audio_prompt = f"You are an AI assistant for creating a voice-over script based on the following slide content. The script should focus only on the slide content, avoiding preamble and conclusion." \
                       f"The voice-over should be engaging, informative, and reflect the main points of the slide:\n\n" \
                       f"Slide Title: {title_text}\n" \
                       f"text_to_speak: {text_to_speak}\n\n" \
                       f"Please provide a complete script that can be used for a presentation, speaking clearly and fluidly."

        # Create the prompt template
        prompt = ChatPromptTemplate(
            [
                ("system", (audio_prompt)),
                ("human", (text_to_speak))
            ]
        )

        chain = prompt | llm


        raw_audio_response = chain.invoke({"text_to_speak": text_to_speak})

        if raw_audio_response and raw_audio_response.content:
            narration_text = raw_audio_response.content.strip()
            print(narration_text)

            if narration_text.strip():
                audio_file_path = os.path.join(audio_folder, f"audio_slide_{slide['id']}.mp3")
                tts = gTTS(text=narration_text, lang="en", slow=False)  # Convert to speech
                tts.save(audio_file_path)
                audio_files.append(audio_file_path)

                # Calculate the length of the audio
                audio_clip = AudioFileClip(audio_file_path)
                audio_durations.append(audio_clip.duration)

    return audio_files, audio_durations  # Return audio durations along with file paths

# Function to convert PowerPoint slides to images using COM
def ppt_to_images(ppt_file, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    pythoncom.CoInitialize()
    powerpoint = comtypes.client.CreateObject("PowerPoint.Application")
    powerpoint.Visible = 1

    presentation = powerpoint.Presentations.Open(ppt_file)

    slide_images = []
    for i, slide in enumerate(presentation.Slides):
        slide_image_path = os.path.join(output_folder, f"slide_{i + 1}.png")
        slide.Export(slide_image_path, "PNG")
        slide_images.append(slide_image_path)

    presentation.Close()
    powerpoint.Quit()
    pythoncom.CoUninitialize()

    return slide_images

# Function to create video from slides and audio
def create_video_from_slides(slide_images, audio_files, audio_durations, output_video_path):
    image_clips = []

    for img, audio_file, duration in zip(slide_images, audio_files, audio_durations):
        audio_clip = AudioFileClip(audio_file)
        audio_clip = audio_clip.set_duration(duration)  # Match audio duration to the slide duration
        image_clip = ImageClip(img).set_duration(duration).set_audio(audio_clip)
        image_clips.append(image_clip)

    # Concatenate all image clips into a video
    video = concatenate_videoclips(image_clips, method="compose")
    video.write_videofile(output_video_path, fps=24)


# Streamlit app
st.title("YouTube Transcript Fetch and Summarization")

# Search bar
query = st.text_input("Enter your search query:")

# Search results and process
if query:
    results = youtube_search(query, max_results=5)
    transcripts = []

    if results:
        for i, result in enumerate(results):
            st.subheader(f"Video {i+1}")
            st.write(f"Title: {result['title']}")
            st.write(f"URL: {result['url']}")

            # Extract video ID from the URL
            video_id = result['video_id']

            # Get transcript
            with st.spinner("Fetching transcript..."):
                transcript = get_transcript(video_id)
                if transcript:
                    st.write("Transcript:")
                    st.text_area(f"Transcript {i+1}", transcript, height=150)
                    transcripts.append(transcript)
                else:
                    st.error("Transcription failed.")

        if transcripts:
            # Combine all transcripts into one
            combined_transcript = " ".join(transcripts)

            # Display the combined transcript
            st.subheader("Combined Transcript")
            st.text_area("Combined Transcript:", combined_transcript, height=250)

            # Add a button to generate the summary
            if st.button("Summarize Transcript"):
                with st.spinner("Summarizing transcript..."):
                    summary = summarize_transcripts(combined_transcript)
                    st.session_state.transcript = summary
                    st.write("Summary:")
                    st.text_area("Summarized Transcript:", summary, height=200)
    else:
        st.warning("No videos with transcripts found.")

    if st.button("Generate Video"):
        with st.spinner("Loading video transcript..."):
            st.success("Transcript loaded.")

        if st.session_state.transcript:
            try:
                with tempfile.TemporaryDirectory() as tmp_dir:
                    progress_bar = st.progress(0)  # Initialize progress bar
                    total_steps = 5

                    ppt_file = os.path.join(tmp_dir, "output.pptx")
                    audio_folder = os.path.join(tmp_dir, "audio_files")
                    video_file = os.path.join(tmp_dir, "output.mp4")
                    slide_folder = os.path.join(tmp_dir, "slide_images")

                    # Create necessary directories
                    os.makedirs(audio_folder, exist_ok=True)
                    os.makedirs(slide_folder, exist_ok=True)

                    # Step 1: Generate PowerPoint from text
                    slides_json = generate_ppt_json(st.session_state.transcript)
                    create_ppt_from_json(slides_json, ppt_file)
                    progress_bar.progress(1 / total_steps)

                    # Step 2: Generate audio for each slide using AI
                    audio_files, audio_durations = generate_slide_audio(slides_json, audio_folder)
                    progress_bar.progress(2 / total_steps)

                    # Step 3: Convert PPT slides to images using COM
                    slide_images = ppt_to_images(ppt_file, slide_folder)
                    progress_bar.progress(3 / total_steps)

                    # Step 4: Create video from slides and their corresponding audio
                    create_video_from_slides(slide_images, audio_files, audio_durations, video_file)
                    progress_bar.progress(4 / total_steps)

                    # Prepare data for download buttons
                    with open(video_file, "rb") as f:
                        video_data = f.read()
                    with open(ppt_file, "rb") as ppt_f:
                        ppt_data = ppt_f.read()

                    # Display generated video in the app
                    st.video(video_file)



                    st.download_button(
                        label="Download PowerPoint",
                        data=ppt_data,
                        file_name="presentation.pptx",
                        mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        key="ppt_download"
                    )
                        # Track download status


                    st.download_button(
                        label="Download Video",
                        data=video_data,
                        file_name="presentation_video.mp4",
                        mime="video/mp4",
                        key="video_download"
                    )
                     # Track download status

                    if 'downloaded_ppt' in st.session_state and st.session_state.downloaded_ppt:
                        st.success("PowerPoint downloaded!")

                    if 'downloaded_video' in st.session_state and st.session_state.downloaded_video:
                        st.success("Video downloaded!")

            except NotADirectoryError as e:
                st.error(f"Directory error: {str(e)}")
            except Exception as e:
                st.error(f"An unexpected error occurred: {str(e)}")

